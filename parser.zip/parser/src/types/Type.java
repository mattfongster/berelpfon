package types;

public enum Type
{
    INT, BOOL, DOUBLE
}
