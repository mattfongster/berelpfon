package ast;

import java.util.Map;
import ntree.Expr;
import ntree.NDouble;
import types.Type;

public class Dble implements IExpression
{
    private double value;

    public Dble(double value)
    {
        this.value = value;
    }

    @Override
    public Expr typecheck(Map<String,Type> typeEnvironment)
    {
        return new NDouble(value);
    }
}
