package ast;

//  a node that is an expression
import java.util.Map;
import ntree.Expr;
import types.Type;
import types.TypeException;

public interface IExpression extends TypeCheckable
{
    public Expr typecheck(Map<String, Type> typeEnvironment) throws TypeException;
}
