/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

import java.util.Map;
import ntree.Expr;
import types.Type;
import types.TypeException;

/**
 *
 * @author Greg
 */
public class Flt implements IExpression
{
    float value;

    public Flt(float value)
    {
        this.value = value;
    }

    public float getValue()
    {
        return value;
    }

    @Override
    public Expr typecheck(Map<String, Type> typeEnvironment) throws TypeException
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
