/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

import java.util.Map;
import ntree.ITree;
import types.Type;
import types.TypeException;

/**
 *
 * @author Greg
 */
public class Declaration implements TypeCheckable
{

    String value;

    public String getValue()
    {
        return value;
    }

    public Declaration(String value)
    {
        this.value = value;
    }

    @Override
    public ITree typecheck(Map<String, Type> typeEnvironment) throws TypeException
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
