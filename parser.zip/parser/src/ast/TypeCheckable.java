package ast;

import ntree.ITree;
import java.util.Map;
import types.Type;
import types.TypeException;

public interface TypeCheckable
{
    ITree typecheck(Map<String, Type> typeEnvironment) throws TypeException;
}
