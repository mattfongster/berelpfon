package ast;

import java.util.Map;
import ntree.Expr;
import ntree.NInt;
import types.Type;

public class Int implements IExpression
{
    private int value;

    public Int(int value)
    {
        this.value = value;
    }

    @Override
    public Expr typecheck(Map<String,Type> typeEnvironment)
    {
        return new NInt(value);
    }
}
