package ast;

import java.util.Map;
import ntree.Expr;
import types.Type;
import types.TypeException;

public class Identifier implements IExpression
{
    private String name;

    public Identifier(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    @Override
    public Expr typecheck(Map<String, Type> typeEnvironment) throws TypeException
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
