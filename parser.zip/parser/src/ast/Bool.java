package ast;

import java.util.Map;
import ntree.Expr;
import ntree.NBool;
import types.Type;

public class Bool implements IExpression
{
    private boolean value;

    public Bool(boolean value)
    {
        this.value = value;
    }

    @Override
    public Expr typecheck(Map<String,Type> typeEnvironment)
    {
        return new NBool(value);
    }
}
