package ast;

import java.util.Map;
import ntree.Expr;
import ntree.ITree;
import ntree.NAssignment;
import ntree.NIdentifier;
import types.Type;
import types.TypeException;

public class Assignment implements TypeCheckable
{
    private Identifier lhs;
    private IExpression rhs;

    public Assignment(Identifier lhs, IExpression rhs)
    {
        this.lhs = lhs;
        this.rhs = rhs;
    }
    
    public ITree typecheck(Map<String,Type> typeEnvironment) throws TypeException
    {
        Expr r = rhs.typecheck(typeEnvironment);
        typeEnvironment.put(lhs.getName(), r.getType());
        //  not going to use the result
        return new NAssignment(new NIdentifier(lhs.getName(), r.getType()), r);
    }
}
