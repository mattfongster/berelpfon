package ast;

import java.util.Map;
import ntree.Expr;
import ntree.NMult;
import ntree.Promote;
import types.Type;
import types.TypeException;

public class Mult implements IExpression
{
    private IExpression left;
    private IExpression right;

    public Mult(IExpression left, IExpression right)
    {
        this.left = left;
        this.right = right;
    }

    private void checkIsNumeric(Expr e) throws TypeException
    {
        if (e.getType() != Type.INT && e.getType() != Type.DOUBLE)
        {
            throw new TypeException("Non numeric arguments");
            //  type checking error
        }
    }

    @Override
    public Expr typecheck(Map<String, Type> typeEnvironment) throws TypeException
    {
        Expr l = left.typecheck(typeEnvironment);
        checkIsNumeric(l);

        Expr r = right.typecheck(typeEnvironment);
        checkIsNumeric(r);

        if (l.getType() == Type.INT && r.getType() == Type.INT)
        {
            return new NMult(l, r);
        }
        else
        {
            Expr nl, nr;
            if (l.getType() == Type.INT)
            {
                nl = new Promote(Type.DOUBLE, l);
            }
            else
            {
                nl = l;
            }
            if (r.getType() == Type.INT)
            {
                nr = new Promote(Type.DOUBLE, r);
            }
            else
            {
                nr = r;
            }
            return new NMult(nl, nr);
        }
    }
}
