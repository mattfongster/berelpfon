/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.io.StringReader;

/**
 *
 * @author Greg
 */
public class Parser
{
    public static void main(String[] args) throws ParseException
    {
        String code = "";
        StringReader str = new StringReader(code);
        PatinaParser p = new PatinaParser(str);
        p.Input();
        
    }
}
