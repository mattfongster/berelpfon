package ntree;

import types.Type;

public class Expr implements ITree
{
    private Type type;

    public Expr(Type type)
    {
        this.type = type;
    }

    public Type getType()
    {
        return type;
    }
}
