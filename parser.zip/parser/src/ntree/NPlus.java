package ntree;

public class NPlus extends Expr
{
    private Expr left;
    private Expr right;

    public NPlus(Expr left, Expr right)
    {
        super(left.getType());
        assert left.getType() == right.getType();
        this.left = left;
        this.right = right;
    }
}
