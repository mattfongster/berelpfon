package ntree;

import types.Type;

public class Promote extends Expr
{
    private Expr node;

    public Promote(Type type, Expr node)
    {
        super(type);
        this.node = node;
    }
}
