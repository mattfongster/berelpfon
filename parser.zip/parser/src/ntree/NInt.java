package ntree;

import types.Type;

public class NInt extends Expr
{
    private int value;

    public NInt(int value)
    {
        super(Type.INT);
        this.value = value;
    }

}
