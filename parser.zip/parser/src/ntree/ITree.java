package ntree;

/**
    A node that can be the result of type checking
 */
public interface ITree
{
    
}
