package ntree;

import types.Type;

public class NDouble extends Expr
{
    private double value;

    public NDouble(double value)
    {
        super(Type.DOUBLE);
        this.value = value;
    }

}
