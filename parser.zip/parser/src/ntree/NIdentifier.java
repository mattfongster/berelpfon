package ntree;

import types.Type;

public class NIdentifier extends Expr
{
    private String name;

    public NIdentifier(String name, Type type)
    {
        super(type);
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
