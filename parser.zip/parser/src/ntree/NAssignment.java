package ntree;

public class NAssignment implements ITree
{
    private NIdentifier lhs;
    private Expr rhs;

    public NAssignment(NIdentifier lhs, Expr rhs)
    {
        this.lhs = lhs;
        this.rhs = rhs;
    }

}
