package ntree;

import types.Type;

public class NBool extends Expr
{
    private boolean value;

    public NBool(boolean value)
    {
        super(Type.BOOL);
        this.value = value;
    }

}
